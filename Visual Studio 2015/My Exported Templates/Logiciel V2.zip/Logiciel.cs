﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Logiciel : Form
    {
        public Logiciel()
        {
            InitializeComponent();
        }

        private void ajouterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            $safeprojectname$.Ajouterclient ajouterclient;
            ajouterclient = new $safeprojectname$.Ajouterclient();
            ajouterclient.MdiParent = this;
            ajouterclient.Show();
        }

        private void modifierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            $safeprojectname$.Modifierclient modifierclient;
            modifierclient = new $safeprojectname$.Modifierclient();
            modifierclient.MdiParent = this;
            modifierclient.Show();
        }

        private void consulterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            $safeprojectname$.Consulterclient consulterclient;
            consulterclient = new $safeprojectname$.Consulterclient();
            consulterclient.MdiParent = this;
            consulterclient.Show();
        }

        private void parTypeDeClientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            $safeprojectname$.CAclient Caclient;
            Caclient = new $safeprojectname$.CAclient();
            Caclient.MdiParent = this;
            Caclient.Show();
        }

        private void parFournisseurToolStripMenuItem_Click(object sender, EventArgs e)
        {
            $safeprojectname$.Cafournisseur Cafournisseur;
            Cafournisseur = new $safeprojectname$.Cafournisseur();
            Cafournisseur.MdiParent = this;
            Cafournisseur.Show();
        }

        private void totalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            $safeprojectname$.CAtotal Catotal;
            Catotal = new $safeprojectname$.CAtotal();
            Catotal.MdiParent = this;
            Catotal.Show();
        }

        private void catalogueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            $safeprojectname$.Catalogue Catalogue;
            Catalogue = new $safeprojectname$.Catalogue();
            Catalogue.MdiParent = this;
            Catalogue.Show();
        }

        private void produitsCommandésToolStripMenuItem_Click(object sender, EventArgs e)
        {
            $safeprojectname$.Produitcommandes Prodcommandes;
            Prodcommandes = new $safeprojectname$.Produitcommandes();
            Prodcommandes.MdiParent = this;
            Prodcommandes.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ajouterToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            $safeprojectname$.creercommande creercommande;
            creercommande = new $safeprojectname$.creercommande();
            creercommande.MdiParent = this;
            creercommande.Show();
        }

        private void ajouterToolStripMenuItem4_Click(object sender, EventArgs e)
        {
            $safeprojectname$.ajouterproduit newproduit;
            newproduit = new $safeprojectname$.ajouterproduit();
            newproduit.MdiParent = this;
            newproduit.Show();
        }
    }
}
